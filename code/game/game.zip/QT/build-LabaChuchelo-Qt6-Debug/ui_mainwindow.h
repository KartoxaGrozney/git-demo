/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.3.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QPushButton *ButtonNewGame;
    QPushButton *ButtonExit;
    QLabel *label;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *student;
    QPushButton *teacher;
    QPushButton *mellstroy;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *mell;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->setEnabled(true);
        MainWindow->resize(1915, 1091);
        MainWindow->setAutoFillBackground(false);
        MainWindow->setStyleSheet(QString::fromUtf8("QMainWindow {\n"
"    background-image: url(\"/home/alex/MY/QT/LabaChuchelo/images/background.jpg\");\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}"));
        MainWindow->setDocumentMode(false);
        MainWindow->setDockNestingEnabled(false);
        MainWindow->setUnifiedTitleAndToolBarOnMac(false);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        ButtonNewGame = new QPushButton(centralwidget);
        ButtonNewGame->setObjectName(QString::fromUtf8("ButtonNewGame"));
        ButtonNewGame->setGeometry(QRect(80, 50, 301, 101));
        QFont font;
        font.setPointSize(15);
        ButtonNewGame->setFont(font);
        ButtonExit = new QPushButton(centralwidget);
        ButtonExit->setObjectName(QString::fromUtf8("ButtonExit"));
        ButtonExit->setGeometry(QRect(80, 190, 301, 101));
        ButtonExit->setFont(font);
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(1670, 630, 111, 31));
        QFont font1;
        font1.setPointSize(26);
        label->setFont(font1);
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(1650, 700, 151, 81));
        pushButton->setFont(font);
        pushButton_2 = new QPushButton(centralwidget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(1650, 810, 151, 81));
        pushButton_2->setFont(font);
        pushButton_3 = new QPushButton(centralwidget);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(1650, 920, 151, 81));
        pushButton_3->setFont(font);
        student = new QPushButton(centralwidget);
        student->setObjectName(QString::fromUtf8("student"));
        student->setGeometry(QRect(1090, 220, 131, 61));
        student->setFont(font);
        teacher = new QPushButton(centralwidget);
        teacher->setObjectName(QString::fromUtf8("teacher"));
        teacher->setGeometry(QRect(1390, 220, 131, 61));
        teacher->setFont(font);
        mellstroy = new QPushButton(centralwidget);
        mellstroy->setObjectName(QString::fromUtf8("mellstroy"));
        mellstroy->setGeometry(QRect(1700, 220, 121, 61));
        mellstroy->setFont(font);
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(1030, 20, 231, 161));
        label_2->setMaximumSize(QSize(20000, 10000));
        label_2->setMouseTracking(false);
        label_2->setTabletTracking(false);
        label_2->setAcceptDrops(false);
        label_2->setAutoFillBackground(false);
        label_2->setPixmap(QPixmap(QString::fromUtf8("images/aziavic.png")));
        label_2->setScaledContents(true);
        label_2->setWordWrap(false);
        label_2->setOpenExternalLinks(false);
        label_3 = new QLabel(centralwidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(1310, 60, 291, 121));
        label_3->setPixmap(QPixmap(QString::fromUtf8("images/zubovich.png")));
        label_3->setScaledContents(true);
        mell = new QLabel(centralwidget);
        mell->setObjectName(QString::fromUtf8("mell"));
        mell->setGeometry(QRect(1680, 40, 161, 141));
        mell->setPixmap(QPixmap(QString::fromUtf8("images/mell.png")));
        mell->setScaledContents(true);
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1915, 19));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        ButtonNewGame->setText(QCoreApplication::translate("MainWindow", "New Game", nullptr));
        ButtonExit->setText(QCoreApplication::translate("MainWindow", "Exit", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "LeveL", nullptr));
        pushButton->setText(QCoreApplication::translate("MainWindow", "Easy", nullptr));
        pushButton_2->setText(QCoreApplication::translate("MainWindow", "Normal", nullptr));
        pushButton_3->setText(QCoreApplication::translate("MainWindow", "Hard", nullptr));
        student->setText(QCoreApplication::translate("MainWindow", "Student", nullptr));
        teacher->setText(QCoreApplication::translate("MainWindow", "Teacher", nullptr));
        mellstroy->setText(QCoreApplication::translate("MainWindow", "Mellstroy", nullptr));
        label_2->setText(QString());
        label_3->setText(QString());
        mell->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
