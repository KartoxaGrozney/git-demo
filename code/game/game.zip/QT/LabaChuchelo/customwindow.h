#ifndef CUSTOMWINDOW_H
#define CUSTOMWINDOW_H

#include <QLabel>
#include <QMainWindow>
#include <QSoundEffect>
#include <QMouseEvent>
#include <QMediaPlayer>
#include <QUrl>
#include <QPropertyAnimation>
#include <QGraphicsScene>
#include <QGraphicsPixmapItem>
#include <QGraphicsItemAnimation>
#include <QTimeLine>
#include <QSettings>
#include <QDialog>
#include <QVector>
#include <QString>
#include <QPushButton>


class QLabel;
class QTimer;

class CustomWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit CustomWindow(QWidget* parent = nullptr);

private:
    int clickCount = 0;
    QLabel *photoLabel;
    QLabel *carLabel;
    int speedX = 2;
    int speedY = 3;
    int remainingHearts = 3;
    QSoundEffect clickSound;
    void handlePhotoLabelClicked(QMouseEvent* event);
    bool eventFilter(QObject* obj, QEvent* event) override;
    const int sizeHeight = 120;
    const int sizeWidth = 120;
    QList<QLabel*> hearts;
    QTimer* timer;
    QSettings settings;
    int m_speed;
    QSettings settingsPers;
    int m_pers;

    QPixmap photoPixmap;
    QPixmap photoPixmap2;
    QPixmap photoPixmap3;
    QString link1;
    QString link2;
    QString link3;
    // QPointer<QPushButton> buttonClose = new QPushButton(this);

private slots:
    void movePhoto();
};

#endif // CUSTOMWINDOW_H
