#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "customwindow.h"

#include <QDialog>
#include <QCursor>
#include <QPixmap>
#include <QLabel>
#include <QMouseEvent>
#include <QApplication>
#include <QScreen>
#include <QSize>
#include <QTimer>
#include <QGuiApplication>
#include <QSettings>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //m_pers = settingsPers.value("myPers", 0).toInt();
    // Загрузка изображения из ресурсов
    QPixmap pixmap("C:/Proga/Qt/QT/LabaChuchelo/images/aziavic.png");
    ui->label_2->setPixmap(pixmap);

    QPixmap pixmap1("C:/Proga/Qt/QT/LabaChuchelo/images/mell.png");
    ui->mell->setPixmap(pixmap1);

    QPixmap pixmap2("C:/Proga/Qt/QT/LabaChuchelo/images/zubovich.png");
    ui->label_3->setPixmap(pixmap2);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_ButtonNewGame_clicked()
{
    CustomWindow *newWindow = new CustomWindow(this);
    newWindow->showFullScreen();

    QPixmap cursorPixmap("C:/Proga/Qt/QT/LabaChuchelo/images/bita.png");
    QSize newSize = cursorPixmap.size() / 5;
    cursorPixmap = cursorPixmap.scaled(newSize, Qt::KeepAspectRatio);
    QCursor customCursor(cursorPixmap, newSize.width() / 5, newSize.height() / 5);
    newWindow->setCursor(customCursor);
}


void MainWindow::on_ButtonExit_clicked()
{
    QCoreApplication::quit();
}

void MainWindow::on_pushButton_clicked()
{
    m_speed = 4;
    settings.setValue("myVariable", m_speed);
}


void MainWindow::on_pushButton_2_clicked()
{
    m_speed = 2;
    settings.setValue("myVariable", m_speed);
}


void MainWindow::on_pushButton_3_clicked()
{
    m_speed = 1/4;
    settings.setValue("myVariable", m_speed);
}

void MainWindow::on_student_clicked()
{
    m_pers = 1;
    settingsPers.setValue("myPers", m_pers);
}

void MainWindow::on_teacher_clicked()
{
    m_pers = 2;
    settingsPers.setValue("myPers", m_pers);
}

void MainWindow::on_mellstroy_clicked()
{
    m_pers = 3;
    settingsPers.setValue("myPers", m_pers);
}






//void MainWindow::on_label_2_linkActivated(const QString &link)
//{

//}


//void MainWindow::on_label_3_linkActivated(const QString &link)
//{

//}


//void MainWindow::on_mell_linkActivated(const QString &link)
//{

//}

