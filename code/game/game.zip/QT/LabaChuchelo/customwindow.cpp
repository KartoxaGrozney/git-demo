#include "customwindow.h"

#include <QLabel>
#include <QPixmap>
#include <QTimer>
#include <QPointer>
#include <QRandomGenerator>
#include <QMouseEvent>
#include <QMediaPlayer>
#include <QUrl>
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QGraphicsPixmapItem>
#include <QPropertyAnimation>
#include <QDateTime>
#include <QPushButton>
#include <QGuiApplication>
#include <QScreen>
#include <QSettings>

CustomWindow::CustomWindow(QWidget *parent) : QMainWindow(parent)
{
    // Создание и размещение трех фото-сердец
    for (int i = 0; i < 3; ++i) {
        QLabel* heartLabel = new QLabel(this);
        QPixmap heartPixmap("C:/Proga/Qt/QT/LabaChuchelo/images/heart.png");
        heartLabel->setPixmap(heartPixmap);
        heartLabel->setScaledContents(true);
        heartLabel->setSizePolicy(QSizePolicy::Ignored, QSizePolicy::Ignored);
        heartLabel->setFixedSize(120, 120);
        heartLabel->move(10 + i * 100, 10);
        hearts.append(heartLabel);
    }

    link1 = "C:/Proga/Qt/QT/LabaChuchelo/images/aziava.png";
    link2 = "C:/Proga/Qt/QT/LabaChuchelo/images/aziava1.png";
    link3 = "C:/Proga/Qt/QT/LabaChuchelo/images/aziava2.png";
    m_pers = settingsPers.value("myPers", 0).toInt();
    if(m_pers == 1){
        link1 = "C:/Proga/Qt/QT/LabaChuchelo/images/aziava.png";
        link2 = "C:/Proga/Qt/QT/LabaChuchelo/images/aziava1.png";
        link3 = "C:/Proga/Qt/QT/LabaChuchelo/images/aziava2.png";
    }
    else if(m_pers == 2){
        link1 = "C:/Proga/Qt/QT/LabaChuchelo/images/zubovich.png";
        link2 = "C:/Proga/Qt/QT/LabaChuchelo/images/zubovich2.png";
        link3 = "C:/Proga/Qt/QT/LabaChuchelo/images/zubovich3.png";
    }
    else if(m_pers == 3){
        link1 = "C:/Proga/Qt/QT/LabaChuchelo/images/mell1.png";
        link2 = "C:/Proga/Qt/QT/LabaChuchelo/images/mell2.png";
        link3 = "C:/Proga/Qt/QT/LabaChuchelo/images/mell3.png";
    }

    // Set up the main window
    setWindowTitle("Custom Window");
    setWindowFlags(Qt::Window | Qt::CustomizeWindowHint | Qt::WindowCloseButtonHint);
    setGeometry(100, 100, 800, 600);

    // Load the close icon image
    QPixmap closeIcon("C:/Proga/Qt/QT/LabaChuchelo/images/menu.png");
    // Create the close button
    QPointer<QPushButton> buttonClose = new QPushButton(this);
    buttonClose->setObjectName("buttonClose");
    buttonClose->setIcon(closeIcon);
    buttonClose->setIconSize(QSize(80, 80));
    buttonClose->setFixedSize(80, 80); // Set the button size
    buttonClose->setFlat(true);
    buttonClose->move(1800, 30);

    // Connect the button click signal to the close slot
    connect(buttonClose, &QPushButton::clicked, this, &CustomWindow::close);

    QLabel* carLabel = new QLabel(this);
    QPixmap carPixmap("C:/Proga/Qt/QT/LabaChuchelo/images/grob.png");
    carLabel->setPixmap(carPixmap);
    carLabel->setScaledContents(true);
    carLabel->setSizePolicy(QSizePolicy::Ignored, QSizePolicy::Ignored);
    QSize newSize1(200, 200);
    QPixmap scaledPixmap1 = carPixmap.scaled(newSize1, Qt::KeepAspectRatio);
    carLabel->setPixmap(scaledPixmap1);
    carLabel->setFixedSize(newSize1);
    carLabel->hide();

    photoLabel = new QLabel(this);

        QPixmap photoPixmap(link1);
    photoLabel->setPixmap(photoPixmap);
    photoLabel->setScaledContents(true);
    photoLabel->setSizePolicy(QSizePolicy::Ignored, QSizePolicy::Ignored);

    QSize newSize(sizeWidth, sizeHeight);
    QPixmap scaledPixmap = photoPixmap.scaled(newSize, Qt::KeepAspectRatio);
    photoLabel->setPixmap(scaledPixmap);
    photoLabel->setFixedSize(newSize);

    photoLabel->installEventFilter(this);
    clickSound.setSource(QUrl::fromLocalFile("C:/Proga/Qt/QT/LabaChuchelo/images/minecraft_death.wav"));

    bool gameOverShown = false; // Флаг, чтобы отслеживать, была ли показана надпись "Game over"
    m_speed = settings.value("myVariable", 0).toInt();


    QTimer* timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, [this, carLabel, &gameOverShown]() {
        // Код, который будет выполняться при каждом срабатывании таймера
        movePhoto();

        // Код, который будет выполняться после завершения работы таймера
        if (speedX == 0 && speedY == 0){
            carLabel->show();
            QPropertyAnimation *animation = new QPropertyAnimation(carLabel, "geometry");
            animation->setDuration(2500); // Время анимации в миллисекундах
            animation->setStartValue(QRect(-carLabel->width(), photoLabel->y(), carLabel->width(), carLabel->height()));
            animation->setEndValue(QRect(photoLabel->geometry())); // Устанавливаем конечные координаты такие же, как у aziava
            animation->setEasingCurve(QEasingCurve::OutQuad);
            animation->start();

            // Скрыть aziava после окончания анимации
            connect(animation, &QPropertyAnimation::finished, this, [this, carLabel]() {
                photoLabel->hide();

                QPropertyAnimation *animation2 = new QPropertyAnimation(carLabel, "geometry");
                animation2->setDuration(2500); // Время анимации в миллисекундах
                animation2->setStartValue(carLabel->geometry());
                animation2->setEndValue(QRect(width(), carLabel->y(), carLabel->width(), carLabel->height()));
                animation2->setEasingCurve(QEasingCurve::OutQuad);

                // Запускаем вторую анимацию
                animation2->start();
            });


            if (speedX == 0 && speedY == 0 && !gameOverShown) {
                gameOverShown = true; // Установить флаг, что надпись "Game over" показана

                // Показать надпись "Game over" через 6 секунд
                QTimer::singleShot(5500, this, [this]() {
                    // Создать и показать надпись "Game over"
                    QLabel* gameOverLabel = new QLabel(this);
                    gameOverLabel->setText("You Won");
                    gameOverLabel->setAlignment(Qt::AlignCenter);
                    gameOverLabel->setGeometry(0, 0, width(), height());

                    QFont font = gameOverLabel->font(); // Получить текущий шрифт
                    int fontSize = font.pointSize(); // Получить текущий размер шрифта
                    font.setPointSize(fontSize * 7); // Увеличить размер шрифта в 5 раз
                    gameOverLabel->setFont(font); // Установить новый шрифт

                    gameOverLabel->show();
                });

                // Закрыть окно через 11 секунд
                QTimer::singleShot(8000, this, &QWidget::close);
            }
        }
    });
    //timer->start(m_speed);
    timer->start(6);

}

void CustomWindow::movePhoto()
{
    if (remainingHearts > 0) {
        QPoint currentPos = photoLabel->pos();
        int newX = currentPos.x() + speedX;
        int newY = currentPos.y() + speedY;

        if(remainingHearts == 2 ){
            QPixmap photoPixmap2(link2);
            photoLabel->setPixmap(photoPixmap2);
        }
        if(remainingHearts == 1){
            QPixmap photoPixmap3(link3);
            photoLabel->setPixmap(photoPixmap3);
        }
        // Проверка достижения границ экрана по оси X
        if (newX <= 0) {
            newX = 0;
            speedX = QRandomGenerator::global()->bounded(1, 4); // Случайное число от 1 до 3
        } else if (newX + photoLabel->width() >= width()) {
            newX = width() - photoLabel->width();
            speedX = QRandomGenerator::global()->bounded(-3, 0); // Случайное число от -3 до -1
        }

        // Проверка достижения границ экрана по оси Y
        if (newY <= 0) {
            newY = 0;
            speedY = QRandomGenerator::global()->bounded(1, 4); // Случайное число от 1 до 3
        } else if (newY + photoLabel->height() >= height()) {
            newY = height() - photoLabel->height();
            speedY = QRandomGenerator::global()->bounded(-3, 0); // Случайное число от -3 до -1
        }

        photoLabel->move(newX, newY);
    } else {
        speedX = 0;
        speedY = 0;

        QTimer* timer = qobject_cast<QTimer*>(sender());
        if (timer)
        {
            timer->stop();
        }
    }
}

void CustomWindow::handlePhotoLabelClicked(QMouseEvent* event)
{
    if (event->button() == Qt::LeftButton) {
        if (remainingHearts > 0) {
            hearts.at(remainingHearts - 1)->hide();
            remainingHearts--;
            clickSound.play();
        }
    }
}

bool CustomWindow::eventFilter(QObject* obj, QEvent* event)
{
    if (event->type() == QEvent::MouseButtonPress) {
        if (obj == photoLabel) {
            handlePhotoLabelClicked(static_cast<QMouseEvent*>(event));
            return true;
        }
    }

    return QObject::eventFilter(obj, event);
}

