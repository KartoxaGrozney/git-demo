#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLabel>
#include <QSettings>

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class CustomWindow;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_ButtonNewGame_clicked();

    void on_ButtonExit_clicked();

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_student_clicked();

    void on_label_2_linkActivated(const QString &link);

    void on_label_3_linkActivated(const QString &link);

    void on_mell_linkActivated(const QString &link);

    void on_teacher_clicked();

    void on_mellstroy_clicked();

private:
    Ui::MainWindow *ui;
    int m_speed = 3;
    QSettings settings;

    int m_pers = 1;
    QSettings settingsPers;
};

#endif // MAINWINDOW_H
